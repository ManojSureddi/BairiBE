module.exports = [{
	"card": {
		"name": "two",
		"value": "2"
	},
	"category": "heart"
}, {
	"card": {
		"name": "three",
		"value": "3"
	},
	"category": "heart"
}, {
	"card": {
		"name": "four",
		"value": "4"
	},
	"category": "heart"
}, {
	"card": {
		"name": "five",
		"value": "5"
	},
	"category": "heart"
}, {
	"card": {
		"name": "six",
		"value": "6"
	},
	"category": "heart"
}, {
	"card": {
		"name": "seven",
		"value": "7"
	},
	"category": "heart"
}, {
	"card": {
		"name": "eight",
		"value": "8"
	},
	"category": "heart"
}, {
	"card": {
		"name": "nine",
		"value": "9"
	},
	"category": "heart"
}, {
	"card": {
		"name": "ten",
		"value": "10"
	},
	"category": "heart"
}, {
	"card": {
		"name": "Ace",
		"value": "A"
	},
	"category": "heart"
}, {
	"card": {
		"name": "Jockey",
		"value": "J"
	},
	"category": "heart"
}, {
	"card": {
		"name": "Queen",
		"value": "Q"
	},
	"category": "heart"
}, {
	"card": {
		"name": "King",
		"value": "K"
	},
	"category": "heart"
}, {
	"card": {
		"name": "two",
		"value": "2"
	},
	"category": "spade"
}, {
	"card": {
		"name": "three",
		"value": "3"
	},
	"category": "spade"
}, {
	"card": {
		"name": "four",
		"value": "4"
	},
	"category": "spade"
}, {
	"card": {
		"name": "five",
		"value": "5"
	},
	"category": "spade"
}, {
	"card": {
		"name": "six",
		"value": "6"
	},
	"category": "spade"
}, {
	"card": {
		"name": "seven",
		"value": "7"
	},
	"category": "spade"
}, {
	"card": {
		"name": "eight",
		"value": "8"
	},
	"category": "spade"
}, {
	"card": {
		"name": "nine",
		"value": "9"
	},
	"category": "spade"
}, {
	"card": {
		"name": "ten",
		"value": "10"
	},
	"category": "spade"
}, {
	"card": {
		"name": "Ace",
		"value": "A"
	},
	"category": "spade"
}, {
	"card": {
		"name": "Jockey",
		"value": "J"
	},
	"category": "spade"
}, {
	"card": {
		"name": "Queen",
		"value": "Q"
	},
	"category": "spade"
}, {
	"card": {
		"name": "King",
		"value": "K"
	},
	"category": "spade"
}, {
	"card": {
		"name": "two",
		"value": "2"
	},
	"category": "club"
}, {
	"card": {
		"name": "three",
		"value": "3"
	},
	"category": "club"
}, {
	"card": {
		"name": "four",
		"value": "4"
	},
	"category": "club"
}, {
	"card": {
		"name": "five",
		"value": "5"
	},
	"category": "club"
}, {
	"card": {
		"name": "six",
		"value": "6"
	},
	"category": "club"
}, {
	"card": {
		"name": "seven",
		"value": "7"
	},
	"category": "club"
}, {
	"card": {
		"name": "eight",
		"value": "8"
	},
	"category": "club"
}, {
	"card": {
		"name": "nine",
		"value": "9"
	},
	"category": "club"
}, {
	"card": {
		"name": "ten",
		"value": "10"
	},
	"category": "club"
}, {
	"card": {
		"name": "Ace",
		"value": "A"
	},
	"category": "club"
}, {
	"card": {
		"name": "Jockey",
		"value": "J"
	},
	"category": "club"
}, {
	"card": {
		"name": "Queen",
		"value": "Q"
	},
	"category": "club"
}, {
	"card": {
		"name": "King",
		"value": "K"
	},
	"category": "club"
}, {
	"card": {
		"name": "two",
		"value": "2"
	},
	"category": "diamond"
}, {
	"card": {
		"name": "three",
		"value": "3"
	},
	"category": "diamond"
}, {
	"card": {
		"name": "four",
		"value": "4"
	},
	"category": "diamond"
}, {
	"card": {
		"name": "five",
		"value": "5"
	},
	"category": "diamond"
}, {
	"card": {
		"name": "six",
		"value": "6"
	},
	"category": "diamond"
}, {
	"card": {
		"name": "seven",
		"value": "7"
	},
	"category": "diamond"
}, {
	"card": {
		"name": "eight",
		"value": "8"
	},
	"category": "diamond"
}, {
	"card": {
		"name": "nine",
		"value": "9"
	},
	"category": "diamond"
}, {
	"card": {
		"name": "ten",
		"value": "10"
	},
	"category": "diamond"
}, {
	"card": {
		"name": "Ace",
		"value": "A"
	},
	"category": "diamond"
}, {
	"card": {
		"name": "Jockey",
		"value": "J"
	},
	"category": "diamond"
}, {
	"card": {
		"name": "Queen",
		"value": "Q"
	},
	"category": "diamond"
}, {
	"card": {
		"name": "King",
		"value": "K"
	},
	"category": "diamond"
}, {
	"card": {
		"name": "Joker",
		"value": "Joker"
	},
	"category": "Joker"
}, {
	"card": {
		"name": "Joker",
		"value": "JOCKER"
	},
	"category": "Joker"
}];
