module.exports = ["heart", "spade", "club", "diamond", "joker"];
