module.exports = {
	A: {
		name: "Ace",
		value: "A"
	},
	2: {
		name: "two",
		value: "2"
	},
	3: {
		name: "three",
		value: "3"
	},
	4: {
		name: "four",
		value: "4"
	},
	5: {
		name: "five",
		value: "5"
	},
	6: {
		name: "six",
		value: "6"
	},
	7: {
		name: "seven",
		value: "7"
	},
	8: {
		name: "eight",
		value: "8"
	},
	9: {
		name: "nine",
		value: "9"
	},
	10: {
		name: "ten",
		value: "10"
	},
	J: {
		name: "Jockey",
		value: "J"
	},
	Q: {
		name: "Queen",
		value: "Q"
	},
	K: {
		name: "King",
		value: "K"
	},
	JOCKER: {
		name: "Joker",
		value: "Joker"
	}
};
