class ValidateShow{
	static isMainLife(groups){
		let max=0 ,min=0;
		groups.forEach((group)=>{
			group.forEach(()=>{

			});
		});
	}
	static isMultiplet(groups){

	}

	static validate(){

	}
}
