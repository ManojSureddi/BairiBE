const gameService = require("../services/game");

class Game{
  static show((request,response)=>{

  });

  static cards((request,response)=>{

  });

  static toss((request,response)=>{

  });
}
